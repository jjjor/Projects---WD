$(function(){
    $("#aparecer").click(function(){
        $('div').show();
    });
});

$(function(){
    $('#fechar').click(function(){
        $('div').hide()
    })
})

$(function(){
    $('#cancelar').click(function(){
        $('div').hide()
    })
})

$('#ok').click(function() {
    location.load(true);
});
